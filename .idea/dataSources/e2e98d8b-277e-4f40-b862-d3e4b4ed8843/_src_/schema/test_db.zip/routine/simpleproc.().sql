CREATE PROCEDURE `simpleproc`()
  BEGIN
 SELECT COUNT(*) from users;
end