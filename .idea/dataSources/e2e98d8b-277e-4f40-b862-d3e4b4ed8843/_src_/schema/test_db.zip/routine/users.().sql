CREATE PROCEDURE `users`()
  begin
declare num int; 
set num=10001; 
while num < 200000 do 
insert into users(id,name,age,content ) values(num,"tomcat",23,'策部署上来，重点推进“三去一降一补”，不能因为包袱重而等待、困难多而不作为、有风险而躲避、有阵痛而不前，要树立必胜信念，坚定不移把这项工作向前推进。要坚持以人民为中心的发展思想，在全社会大力弘扬勤劳致富、艰苦奋斗精神，激励人们通过劳动创造美好生活，不断提高生活水平。'); 
set num=num+1;
end while;
end